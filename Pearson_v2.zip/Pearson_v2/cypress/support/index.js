require('cypress-xpath')
import './commands'

Cypress.on('uncaught:exception', (err, runnable) => {
    console.table(err.message);
    return false;
  });

beforeEach(() => {
    cy.clearLocalStorage();
  });