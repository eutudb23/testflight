import { commonMethods } from "../common/commonMethods";
import { data, selectors } from '../../config/constants.json';
import { paths } from '../../config/urlpaths.json';

And ('I land on the Pearson page', () => {
    commonMethods.verifyUserIsRedirectedToExpectedPage(paths.pearson_landing_page);
});

Then ('the Pearson page should conatain a search input field', () => {
    commonMethods.waitUntilElementIsVisible(selectors.search_box_text);
});

When ('I input the search term Test in the search input field', () => {
    commonMethods.typeTextIntoElement(selectors.search_box_text, data.search_test);
    // or use this > commonMethods.typeTextIntoElementWithFocus(selectors.search_box_text, 'development')
});

And ('I confirm the search by selecting the search button', () => {
    commonMethods.clickOnElement(selectors.search_button);
});

Then ('I should land on a results page with at most 10 elements', () => {
    commonMethods.verifyUserIsRedirectedToExpectedPage(paths.test_search_results);
    cy.get('.productItem.test').should('have.length', 10)
});

And ('I land on a results page with at most 10 elements', () =>{
    commonMethods.verifyUserIsRedirectedToExpectedPage(paths.test_search_results);
    cy.get('.productItem.test').should('have.length', 10)
});
When ('I select the Next button', () => {
    //search_next_page
    commonMethods.clickOnElement(selectors.search_next_page);
});

And ('I should land on the next page', () => {
    commonMethods.verifyUserIsRedirectedToExpectedPage(paths.test_search_result_next);
});

Then ('I should see the next 10 elements', () => {
    cy.get('.productItem.test').should('have.length', 10)
});

Then ('3rd element from the page should contain the apropiate link', () => {
    //commonMethods.verifyUserIsRedirectedToExpectedPage(paths.proper_article_redirect); //use this in case page loads in the same tab
    cy.get("a[href='https://www.pearson.com/content/dam/one-dot-com/one-dot-com/global/Files/efficacy-and-research/methods/learning-principles/Mobile_Learning-Learner_Affordances.pdf']").should('have.attr', 'href').and('contain', 'Mobile_Learning-Learner_Affordances.pdf');
})