export class CommonMethods {
    checkElementContainsExpectedText(webElement, text) {
      cy.get(webElement, { timeout: 5000 }).contains(text);
    }
  
    typeTextIntoElementWithFocus(webElement, text) {
      cy.get(webElement, { timeout: 5000 }).type(text);
    }
  
    typeTextIntoElement(webElement, text) {
      cy.get(webElement, { timeout: 5000 }).type(text);
    }
  
    verifyUserIsRedirectedToExpectedPage(paths) {
      cy.url({ timeout: 7000 }).should('include', paths);
    }
  
    clickOnElement(webElement) {
      cy.get(webElement, { timeout: 4000 }).click();
      //cy.get('body', { timeout: 2000 }).focus();
    }
  
    clickOnElementUsingForce(webElement) {
      cy.get(webElement, { timeout: 4000 }).click({ force: true });
    }
  
    selectElementFromDropDownByText(webElement, text) {
      cy.get(webElement, { timeout: 3000 }).select(text);
    }
  
    waitUntilElementIsVisible(webElement) {
      cy.get(webElement, { timeout: 5000 }).should('be.visible');
    }
  
    clearField(webElement) {
      cy.get(webElement, { timeout: 3000 }).clear();
    }
  
    clickOutsideField(webElement) {
      cy.get(webElement, { timeout: 3000 }).blur();
    }
  
    navigateToPage(path) {
      cy.visit(path, { timeout: 3000 });
    }
  
    validateUrl(expUrl) {
      cy.url({ timeout: 3000 }).should('include', expUrl);
    }
}
export const commonMethods = new CommonMethods();