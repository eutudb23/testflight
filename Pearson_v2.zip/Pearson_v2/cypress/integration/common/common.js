import { paths } from '../../config/urlpaths.json';

Given('I navigate to the {string} page', (path) => {
    //cy.skipOn(path === 'no where');
    cy.wrap(paths[path]).as('component');
    cy.visit(paths[path]);
  });